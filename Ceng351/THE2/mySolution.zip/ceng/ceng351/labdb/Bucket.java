/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ceng.ceng351.labdb;
//import java.util.Vector;
/**
 *
 * @author furkan
 */
public class Bucket {
    int localDepth;
    int bucketSize;
    int numberOfData;
    String datas[];
    
    public Bucket(int bucket,int localDepthGivenUs) {
        datas = new String[bucket];
        localDepth= localDepthGivenUs;
        bucketSize = bucket;
        numberOfData=0;
        for(int i=0;i<bucketSize;i++){
            datas[i] = "";
        }
    }
    
    public boolean insert(String newEntry){
        if(numberOfData != bucketSize){
            for(int i=0;i<bucketSize;i++){
                if(datas[i].isEmpty()){
                    datas[i] = newEntry;
                    break;
                }
            }
            numberOfData++;
            return true;
        }
        else{
            return false;
        }
    }
    
    public int returnLocalDepth(){
        return localDepth;
    }
    
    public String returnEntries(){
        String temp = "";
        for(int i=0;i<bucketSize;i++){
            if(!datas[i].isEmpty()){
               temp = temp + "<" + datas[i] +">"; 
            }   
        }
        return temp;
    }
    
    public void deleteEntries(){
        numberOfData = 0;
        for(int i=0;i<bucketSize;i++){
            datas[i] = "";
        }
    }
    
    public void increaseLocalDepth(){
        localDepth++;
    }
    
    public void decreaseLocalDepth(){
        localDepth--;
    }
    
    public int getLocalDepth(){
        return localDepth;
    }
    
    public int getNumberOfData(){
        return numberOfData;
    }
    
    public String[] getDatas(){
        return datas;
    }
    
    public boolean searchEntry(String key){
        for(int i=0;i<bucketSize;i++){
            if(datas[i].equals(key)){
                return true;
            }
        }
        return false;
    }
    
    public boolean isEmpty() {
        return numberOfData == 0;
    }
    
    public void deleteEntry(String key){
        for(int i=0;i<bucketSize;i++){
            if(datas[i].equals(key)){
                datas[i] = "";
                numberOfData--;
                break;
            }
        }
    }
    
}
