package ceng.ceng351.labdb;
//import java.util.Vector;


public class LabDB {

    int globalDepth;
    Bucket dataFile[];
    int bucketSizeGlobal;

    public LabDB(int bucketSize) {
        globalDepth = 1;
        dataFile = new Bucket[2];
        dataFile[0] = new Bucket(bucketSize,1);
        dataFile[1] = new Bucket(bucketSize,1);
        bucketSizeGlobal = bucketSize;
    }

    public void enter(String studentID) {
        String numericString = studentID.substring(1);
        int idNumber = Integer.parseInt(numericString);
        int modValue = 1;
        boolean isAdded;
        for(int i=1;i<=globalDepth;i++){
            modValue = modValue*2;
        }
        int bucketNum = idNumber % modValue;
        if(!dataFile[bucketNum].searchEntry(studentID)){
            isAdded = dataFile[bucketNum].insert(studentID);
            if(!isAdded){
                do {
                    doubleBuckets(bucketNum);
                    bucketNum = idNumber % (int) Math.pow(2, globalDepth);
                    isAdded = dataFile[bucketNum].insert(studentID);
                } while (!isAdded);
            }
        }
        
    }

    public void leave(String studentID) {
        String numericString = studentID.substring(1);
        int idNumber = Integer.parseInt(numericString);
        int modValue = 1;
        for(int i=1;i<=globalDepth;i++){
            modValue = modValue*2;
        }
        int bucketNum = idNumber % modValue;
        if(dataFile[bucketNum].searchEntry(studentID)){
            dataFile[bucketNum].deleteEntry(studentID);
            if(dataFile[bucketNum].isEmpty() && globalDepth != 1){
                handleDeleteHashTable(bucketNum,idNumber);
                /*do{
                    
                    handleDeleteHashTable(bucketNum);
                    bucketNum = idNumber % (int) Math.pow(2,globalDepth);
                }while(dataFile[bucketNum].isEmpty()); */
            }
        }
    }

    public String search(String studentID) {
        String numericString = studentID.substring(1);
        int idNumber = Integer.parseInt(numericString);
        int modValue = 1;
        boolean isAdded;
        for(int i=1;i<=globalDepth;i++){
            modValue = modValue*2;
        }
        int bucketNum = idNumber % modValue;
        if(dataFile[bucketNum].searchEntry(studentID)){
            return Integer.toBinaryString( (1 << globalDepth) | bucketNum ).substring(1);
        }
        else{
            return "-1";
        }
        
    }

    public void printLab() {
        int numberOfBucket=1;
        for(int i=1;i<=globalDepth;i++){
            numberOfBucket = numberOfBucket*2;
        }
        System.out.println("Global depth : "+globalDepth);
        for(int i=0;i<numberOfBucket;i++){
            String temp = "";
            temp+= Integer.toBinaryString( (1 << globalDepth) | i ).substring(1);
            temp+= " : [Local depth:";
            temp+= dataFile[i].returnLocalDepth();
            temp+= "]";
            temp+=dataFile[i].returnEntries();
            System.out.println(temp);
        }
    }
    
    private void halveDirectory(){
        int newGlobalDepth = globalDepth-1;
        int newNumberOfBucket = (int) Math.pow(2,newGlobalDepth);
        int oldNumberOfBucket = (int) Math.pow(2,globalDepth);
        int index;
        Bucket tempArr[] = new Bucket[newNumberOfBucket];
        for(int i=0;i<oldNumberOfBucket;i++){
            index = i % newNumberOfBucket;
            tempArr[index] = dataFile[i];
        }
        globalDepth--;
        dataFile = tempArr;
    }
    
    private void handleDeleteHashTable(int bucketNum,int keyOfEntry){
        boolean continueLoop=false;
        do{
        int localDepthOfBucket = dataFile[bucketNum].getLocalDepth();
        int buddyBucketAddress;
        //int returnValue;
        int loopVar = globalDepth - localDepthOfBucket;
        int numberOfBucket = (int) Math.pow(2,globalDepth);
        //int numberOfBuddies = (int) Math.pow(2,loopVar);
        int i;
        boolean allSmall = true;
        int start = bucketNum % (int) Math.pow(2, localDepthOfBucket); // aynı grup
        int buddyNext = (bucketNum >> (localDepthOfBucket-1)) % 2;
        //Bucket buddyBucket;
        if(buddyNext == 0){
            buddyBucketAddress = bucketNum+(int) Math.pow(2,localDepthOfBucket-1);
        }
        else{
            buddyBucketAddress = bucketNum - (int) Math.pow(2,localDepthOfBucket-1);
        }
        continueLoop = dataFile[buddyBucketAddress].getLocalDepth() == dataFile[bucketNum].getLocalDepth();
        if(dataFile[buddyBucketAddress].getLocalDepth() == dataFile[bucketNum].getLocalDepth()){
            for(i=0;i<numberOfBucket;i++){
                if(i % (int) Math.pow(2, localDepthOfBucket) == start){
                    dataFile[i] = dataFile[buddyBucketAddress];
                }
            }
            dataFile[buddyBucketAddress].decreaseLocalDepth();
            for(i=0;i<numberOfBucket;i++){
                if(dataFile[i].getLocalDepth()== globalDepth){
                    allSmall = false;
                }
            }     
            if(allSmall && globalDepth != 1){
                halveDirectory();
                bucketNum = keyOfEntry % (int) Math.pow(2,globalDepth);
                localDepthOfBucket = dataFile[bucketNum].getLocalDepth();
                buddyNext = (bucketNum >> (localDepthOfBucket-1)) % 2;
                //Bucket buddyBucket;
                if(buddyNext == 0){
                    buddyBucketAddress = bucketNum+(int) Math.pow(2,localDepthOfBucket-1);
                }
                else{
                    buddyBucketAddress = bucketNum - (int) Math.pow(2,localDepthOfBucket-1);
               }
                continueLoop = dataFile[buddyBucketAddress].getLocalDepth() == dataFile[bucketNum].getLocalDepth();
            }
        }     
    }while(dataFile[bucketNum].isEmpty() && continueLoop && globalDepth != 1);
        
        
    }
    
    // DELETE KISMI İÇİN UPDATE GELCEK (GELDİ)
    private void doubleBuckets(int bucketNum){
        int localDepthOfBucket = dataFile[bucketNum].getLocalDepth();
        if(localDepthOfBucket == globalDepth){
            int oldGlobalDepth = globalDepth;
            int numberOfOldBucket=1;
            int numberOfNewBucket;
            int j=0;
            for(int i=1;i<=oldGlobalDepth;i++){
                numberOfOldBucket = numberOfOldBucket*2;
            }
            numberOfNewBucket = numberOfOldBucket*2;
            Bucket temp[] = new Bucket[numberOfNewBucket];
            for(int i=0;i<numberOfOldBucket;i++,j++){
                if(i != bucketNum){
                    temp[j] = dataFile[i];
                    temp[j+(int) Math.pow(2, globalDepth)] = dataFile[i]; 
                }
                else{
                    String tempDatas1[];
                    String tempDatas[];
                    int idNumberOfEntry;
                    int whichBucket;
                    Bucket tempBucket = new Bucket(bucketSizeGlobal,localDepthOfBucket+1);
                    tempDatas1 = dataFile[i].getDatas();
                    tempDatas = tempDatas1.clone();
                    dataFile[i].deleteEntries();
                    dataFile[i].increaseLocalDepth();
                    for(int k=0;k<bucketSizeGlobal;k++){
                        if(!tempDatas[k].isEmpty()){
                            String entry = tempDatas[k];
                            idNumberOfEntry = Integer.parseInt(entry.substring(1));
                            whichBucket = idNumberOfEntry >> localDepthOfBucket;
                            whichBucket = whichBucket % 2;
                            if(whichBucket == 0){
                                dataFile[i].insert(entry);
                            }
                            else{
                                tempBucket.insert(entry);
                            }
                        }
                    }
                    temp[j] = dataFile[i];
                    temp[j+ (int) Math.pow(2,globalDepth)] = tempBucket;
                }
            }
            dataFile = temp;
            globalDepth++;
        }
        else{
            //Global Depth ve Local Depth Farklıysa
            int loopVar = globalDepth - localDepthOfBucket;
            int numberOfBucket = (int) Math.pow(2,globalDepth);
            int numberOfBuddies = (int) Math.pow(2,loopVar);
            int i;
            int j;
            int start = bucketNum % (int) Math.pow(2, localDepthOfBucket);
            String tempDatas1[];
            String  tempDatas[];
            int idNumberOfEntry;
            int whichBucket;
            //int numberOfData = dataFile[bucketNum].getNumberOfData();
            tempDatas1 = dataFile[bucketNum].getDatas();
            tempDatas = tempDatas1.clone();
            dataFile[bucketNum].deleteEntries();
            dataFile[bucketNum].increaseLocalDepth();
            Bucket tempBucket = new Bucket(bucketSizeGlobal,localDepthOfBucket+1);
            for(int k=0;k<bucketSizeGlobal;k++){
                if(!tempDatas[k].isEmpty()){
                    String entry = tempDatas[k];
                    idNumberOfEntry = Integer.parseInt(entry.substring(1));
                    whichBucket = idNumberOfEntry >> localDepthOfBucket;
                    whichBucket = whichBucket % 2;
                    if(whichBucket == 0){
                        dataFile[bucketNum].insert(entry);
                    }
                    else{
                        tempBucket.insert(entry);
                    }
                }
            }
            Bucket tempBucket2 = dataFile[bucketNum];
            for(i=0;i<numberOfBucket;i++){
                if(i % (int) Math.pow(2, localDepthOfBucket) == start){
                    if( (i>> localDepthOfBucket) %2 == 0){
                        dataFile[i] = tempBucket2;
                    }
                    else{
                        dataFile[i] = tempBucket;
                    }
                }
            } 
        }
    }
}
